# webclipboard

#### Share your clipboard with your friends using the web


Install using -> `pip install -r req.txt`

If you want to share your clipboard, run -> `python webclipboard.py master`


If you want to receive someone's clipboard, run -> `python webclipboard.py slave`
